# EENG426Lab2
Repo for Fall 2022 EENG426, Lab 2 code
Submission for Anthony Etim and Eddy Zhong


# Part 1
Part 1 consists of the implementation of the logic gates nand2, nor2, an inverter, and a c element.
The scripts for the simulation have also been added as well. The ACT simulation scripts can be run in actsim directly using the source command. 
The IRSIM scripts can be run in irsim using the @ command. 


# Part 2
Part 2 consists of the chp for a 10 place buffer and the simulation code to test it on actsim.
The template for an n place buffer was used here.

For the second part there is an implementation of a priority queue using templated construction. The priority queue consists of n one-place buffers connected linearly, like an n-place FIFO. A for loop was used to check each of the elements within the buffer by monitoring the output from the buffer and to output the smallest number. The test script, test_prio.act, can be run in actsim to test the circuit.